1. Introduction

The accompanying Stata 17 dofile "rep_code_dh_gs.do" and the two main data files "main_panel.dta" and "extended_panel.dta" reproduce all tables and figures from the paper "Profitability and financial leverage: Evidence from a quasi-natural experiment", by Davidson Heath and Giorgo Sertsios.

Because the CRSP/Compustat data in the two main data files cannot be shared publicly, this file includes the Stata 17 code to construct the two main data files using CRSP/Compustat and other data. The other data that are publicly available have been included in this replication package. (see "4. Code to construct main data files", below).

Also included are a variable dictionary for all variables in the two main datafiles (see "2. Variable dictionaries" below), and the Stata output (tables and figures and log file (rep_code_dh_gs.log) from running the main dofile using the two main data files.

Any questions, comments or issues please contact the corresponding author at davidson.heath@eccles.utah.edu.






2. Variable dictionaries

2.1 main_panel.dta

gvkey - Compustat firmid
year - calendar year of the observation
post95 - year > 1995
treated - indicator = 1 if treated firm
DiD - treated * post95
naics4 - 4 digit naics industry
logsale - ln(1 + sale)
logat - ln(1 + at)
ROA - oibdp/at
salesgro - (sale - l.sale) / l.sale
PCM - (sale - cogs - xsga) / sale
Q - (prcc_f*csho-ceq + at-txdb)/at
bklev - debt/at
mktlev - debt/MV
industry_bklev - median of book leverage across the firm's naics4 industry
d_logdebt - d.logdebt
d_logBE - d.logBE
d_logME - d.logME 
debt_issueFG - debt issuance following Frank & Goyal
equity_issueFG - equity issuance following Frank & Goyal
capxat - capx / l.at
RDat - xrd / at
ADat - xad / at
sgaat - xsga / at
RD_Capx - xrd / capx
divpayer - dvt > 0
payout_ratio - payout/oibdp
cash - che / at
d_logcapx - d.logcapx
asset_tangibility - ppent / at
rtnvol - monthly return volatility of the firm's stock that calendar year
log_pats - ln(1 + number of live patents held)
log_tmstk - ln(1 + number of live trademarks held)
age - age since Ritter founding date or first Compustat appearance
logage - ln(1 + age)
cem_weights - weights calculated by coarsened exact matching
l_X - lagged value of variable X, as of the prior year
pretrend_X - firm-level trend in the variable X, in years up to 1995 (inclusive)
pos_tax - (marginal tax rate > 0)
hi_revenue - (revenue > sample median)
hi_size  - (book assets at > sample median)
low_Z - (Altman's Z-score < sample median)
hi_bklev2 - (bklev > sample median)
hi_WW - (Whited-Wu score > sample median)
hi_KZ - (Kaplan-Zingales score > sample median)
DiD_hi_size - DiD * hi_size
post95_pos_tax - post95 * pos_tax
DiD_pos_tax -- DiD * pos_tax
post95_low_Z - post95 * low_Z
DiD_low_Z - DiD * low_Z
post95_hi_bklev2 - post95 * hi_bklev2
DiD_hi_bklev2 - DiD * hi_bklev2
post95_hi_WW - post95 * hi_WW
DiD_hi_WW - DiD * hi_WW
post95_hi_KZ - post95 * hi_KZ
DiD_hi_KZ - DiD * hi_KZ
tmstock95 - # of live trademarks held as of 1995
famous_or_nothing - (tmstock95==0 | treated==1)
lognfamous95 - log(1 + # of famous TMs held as of 1995)
interact2 - post95 * lognfamous95
treated__X -- treated * (year = X)
hi_size_yearX -- hi_size * (year = X)
pos_tax_year* -- pos_tax * (year = X)
dil_treated_* -- treated * diluter * (year = X)


2.2 extended_panel.dta

gvkey - Compustat firmid
year - calendar year of the observation
naics4 - 4 digit naics industry
treated__X - treated * (year = X)
ROA - oibdp/at
bklev - debt/at
l_X - lagged value of variable X, as of the prior year
pretrend95_X - firm-level trend in the variable X, in years up to 1995 (inclusive)
pretrend02_X - firm-level trend in the variable X, in years from 1996 to 2002 (inclusive)





















3. Inputs and code to construct main data files

3.1 Input files: (* means publicly available and included with this dataset)

compustat_annual.dta - Compustat Annual data, downloaded from WRDS in 2020. All accounting #s pre-deflated by the U.S. yearly CPI.
cc_permnos.dta - CRSP/Compustat gvkey to permno mapping
*ritter.dta - Firm inception dates from Jay Ritter's website
firm_monthlyvols.dta - monthly stock return volatility from CRSP
*graham_tax_rates.dta - marginal tax rates from John Graham's website
*patent_counts.dta - firm-year patent data from the USPTO
*tm_data_byfirm.dta - firm-year trademark data from the USPTO
cem_weights.dta - weights calculated by coarsened exact matching (CEM) on firm chars as of 1995



3.2 Stata 17 code:

use compustat_annual, clear
destring gvkey sic sich naics naicsh priusa, replace
replace sic = sich if sich!=.
replace naics = naicsh if naicsh!=.
gen sic3 = floor(sic/10)
gen sic2 = floor(sic/100)
gen naics4 = floor(naics/100)
*filtering
keep if loc=="USA"
drop if naics4==.
keep if priusa==01
*adjust SGA as in Peters & Taylor
gen temp = xsga
replace xsga = xsga - xrd if xrd !=.
replace xsga = xsga - rdip if rdip !=.
replace xsga = temp if xsga!=. & xrd > xsga & xrd < cogs
drop temp
*adjust for operating leases
gen oplease_cap = 8 * xrent
replace at = at + oplease_cap if oplease_cap !=.
*compute book equity as in FF
gen psv = pstkrv
replace psv = pstkl if psv==.
replace psv = pstk if psv==.
gen BE = seq
replace BE = ceq + psv if BE==.
replace BE = at - lt if BE==.
replace BE = BE + txdb if txdb !=.
replace BE = BE + itcb if itcb !=.
replace BE = BE - psv if psv !=.
replace BE = . if BE <= 0
gen logBE = log(1+BE)
replace prcc_f = abs(prcc_f)
gen ME = prcc_f * csho
gen BM = BE / ME
gen MB = ME / BE
gen logMB = log(1+MB)
gen logME = log(1+ME)
gen MV = ME + dlc + dltt + pstkl - txditc
gen debt = dltt + dlc
gen bklev = debt/at
gen mktlev = debt/MV
gen Q = (prcc_f*csho-ceq + at-txdb)/at
replace dvt = 0 if dvt==.
replace prstkc = 0 if prstkc==.
gen divpayer = (dvt > 0)
gen payout = dvt + prstkc
gen payout_ratio = payout / oibdp
*for each firm, take its last observation in year X
gen year = year(datadate)
gen month = month(datadate)
drop if year ==.
*filter tiny / missing obs
drop if at==. | sale ==.| at < 1 | ME==. | sale <0 
sort gvkey year datadate
by gvkey year: drop if _n < _N
tsset gvkey year
replace xrd = 0 if xrd==.
gen RDat = xrd/at
replace xad = 0 if xad==.
gen ADat = xad/at
gen ROA = oibdp/at
gen logsale = ln(1 + sale)
gen salesgro = (sale - l.sale) / l.sale
gen logat = ln(1 + at)
replace txdb = 0 if txdb >=.
replace xsga = 0 if xsga==.
gen sgaat = xsga / at
gen PCM = (sale - cogs - xsga) / sale
replace PCM = oibdp / sale if PCM==.
gen capxat = capx / l.at
gen cash = che/at
gen d_logBE = d.logBE
gen d_logME = d.logME
gen d_logdebt = d.logdebt
merge m:1 gvkey using data/cc_permnos, keep(match master) nogen
merge m:1 permno using data/ritter, keep(match master) nogen
bysort gvkey: egen temp = min(year)
bysort gvkey: egen temp2 = max(Founding)
replace temp2 = temp if temp2 ==.
gen age = year - temp2
gen logage = log(1 + age)
drop temp*
gen asset_tangibility = ppent / at
*Kaplan Zingales measure of financial dependence
gen KZ1 = -1.002*(ib+dp)/ppent
gen KZ2 = 0.283*Q+3.139*bklev
gen KZ3 = -39.368*(dvc+dvp)/ppent
gen KZ4 = -1.315*che/ppent
gen KZ = KZ1+KZ2+KZ3+KZ4
drop KZ1 KZ2 KZ3 KZ4
*modified altman Z-score
gen X1 = ebit / at
gen X2 = sale / at
gen X3 = re / at
gen X4 = (invt + rect - ap) / at
gen Zscore = 3.3 * X1 + 1.0 * X2 + 1.4 * X3 + 1.2 * X4
drop X1 X2 X3 X4
*financing deficit per Frank & Goyal 2003
replace wcapc = 0 if wcapc==.
gen chg_wc = wcapc + chech
replace sppe = 0 if sppe==.
replace fuseo = 0 if fuseo==.
gen cap_inv = capx + ivch + aqc + fuseo + sppe + siv
gen FGfin_deficit = dv + cap_inv + chg_wc - oancf
gen aux_debt=max(dltis,0)
replace aux_debt=0 if bklev!=. & aux_debt==0
gen aux_debtshort=max(dlcch,0)
replace aux_debtshort=0 if bklev!=. & aux_debt==0
gen debt_FG=aux_debtshort+aux_debt
gen debt_issue_ratioFG=debt_FG/l.at 
replace debt_issue_ratioFG=debt_FG/at if year==1989  
gen debt_issueFG =0
replace debt_issueFG=1 if debt_issue_ratioFG>0.05
replace debt_issueFG=. if debt_issue_ratioFG==.
label var debt_issueFG "Debt issuance"
drop aux_debt*
**equity retirement
gen Equity_FG=max(sstk,0)
replace Equity_FG=0 if BE!=. & Equity_FG==0
gen equity_issue_ratioFG=Equity_FG/l.at 
replace equity_issue_ratioFG=Equity_FG/at if year==1989  
gen equity_issueFG =0
replace equity_issueFG=1 if equity_issue_ratioFG>0.05
replace equity_issueFG=. if equity_issue_ratioFG==.
*Whited-Wu financial constraints index
gen divpos = (dv > 0 & dv !=.)
gen tltd = dltt / at
gen cf = oancf / at
preserve
collapse (sum) sale, by(sic3 year)
xtset sic3 year
gen ISG = sale / l.sale
drop sale
save data/ISG, replace
restore
merge m:1 sic3 year using data/ISG, keep(match master) nogen
gen WWfin_constraints = - 0.091*cf - 0.062*divpos + 0.021*tltd - 0.044*logat + 0.102*ISG - 0.035*salesgro
*External financing Rajan Zingales
xtset gvkey year
gen CFO = oancf - (d.invt) - (d.rect) + (d.ap)
gen RZ_findep = (capx - CFO) / capx
gen RZ_eqdep = (sstk - prstkc) / capx
gen RZ_debtdep = RZ_findep - RZ_eqdep
by sic3 year: egen temp1 = mean(cash)
by sic3 year: egen temp2 = sd(cash)
gen zcash = (cash - temp1 ) / temp2
drop temp*
by sic3 year: egen temp1 = sum(xad)
by sic3 year: egen temp2 = sum(xrd)
by sic3 year: egen temp3 = sum(sale)
gen industry_ad_spend = temp1 / temp3
gen industry_rd_spend = temp2 / temp3
drop temp*
merge 1:1 gvkey year month using firm_monthlyvols, keep(match master) nogen
*merge graham tax rates
merge 1:1 gvkey year using graham_tax_rates, keep(match master) nogen
*merge in patent counts & stocks
merge 1:1 gvkey year using patent_counts, keep(match master) nogen
replace npats = 0 if npats==.
replace npats_stk = 0 if npats_stk==.
gen log_pats = log(1+npats)
gen log_patstk = log(1+npats_stk)
*merge in tm data
merge 1:m gvkey year using tm_data_byfirm, keep(match master) nogen
replace n_active_classes = 0 if n_active_classes==.
replace n_tms = 0 if n_tms==.
gen log_tms = log(1+n_tms)
replace tm_stock = 0 if tm_stock==.
gen log_tmstk = log(1+tm_stock)
replace famous21 = 0 if famous21==.
compress
*make extended sample:
preserve
drop if year < 1988 | year > 2012
*keep 1988 just for lagged obs. 
    foreach var in salesgro payout_ratio asset_tangibility Q ROA PCM cash capxat bklev mktlev RDat ADat sgaat RD_Capx {
		qui winsor `var', gen(temp) p(.01)
		qui replace `var' = temp
		drop temp
	}
*lags
bysort sic3 year: egen industry_bklev = median(bklev)
bysort sic3 year: egen industry_mktlev = median(mktlev)
xtset gvkey year
foreach var in salesgro payout_ratio asset_tangibility Q ROA PCM cash capxat bklev mktlev RDat ADat sgaat RD_Capx {
qui gen l_`var' = l.`var'
qui gen d_`var' = d.`var'
}
drop if year < 1989 | year > 2012
gen temp = famous21 if year==1995
replace temp = 0 if temp==.
bysort gvkey: egen nfamous95 = max(temp)
*gen temp = (famous21 > 0 & famous21 !=.) if year==1995
bysort gvkey: gen treated = (nfamous95 > 0)
drop temp
drop if treated==.
gen temp = (famous95textual > 0 & famous95textual !=.) if year==1995
bysort gvkey: egen treated_textual = max(temp)
drop temp
gen temp = tmstock if year==1995
replace temp = 0 if temp==.
bysort gvkey: egen tmstock95 = max(temp)
drop temp
compress
di _N
save data/cc_panel_filtered_extend, replace
codebook gvkey if treated
restore
*make main sample:
drop if year < 1988 | year > 2002
*keep 1988 just for lagged obs. 
    foreach var in salesgro payout_ratio asset_tangibility Q ROA PCM cash capxat bklev mktlev RDat ADat sgaat RD_Capx {
		qui winsor `var', gen(temp) p(.01)
		qui replace `var' = temp
		drop temp
	}
*lags
bysort sic3 year: egen industry_bklev = median(bklev)
bysort sic3 year: egen industry_mktlev = median(mktlev)
xtset gvkey year
foreach var in salesgro payout_ratio asset_tangibility Q ROA PCM cash capxat bklev mktlev RDat ADat sgaat RD_Capx {
qui gen d_`var' = d.`var'
qui gen l_`var' = l.`var'
}
drop if year < 1989 | year > 2002
gen temp = famous21 if year==1995
replace temp = 0 if temp==.
bysort gvkey: egen nfamous95 = max(temp)
*gen temp = (famous21 > 0 & famous21 !=.) if year==1995
bysort gvkey: gen treated = (nfamous95 > 0)
drop temp
drop if treated==.
gen temp = (famous95textual > 0 & famous95textual !=.) if year==1995
bysort gvkey: egen treated_textual = max(temp)
drop temp
gen temp = tmstock if year==1995
replace temp = 0 if temp==.
bysort gvkey: egen tmstock95 = max(temp)
drop temp
compress
di _N
save data/cc_panel_filtered, replace
codebook gvkey if treated










*main sample
use cc_panel_filtered, clear
local didwindow = 7
drop if year < 1996-`didwindow' | year > 1995+`didwindow'
gen post95 = (year >= 1996)
*calculate pretrends
bysort gvkey (year): egen temp = mean(d_bklev) if year < 1996
bysort gvkey (year): egen pretrend_bklev = max(temp)
drop temp
gen DiD = treated*post95
label var DiD "Treated_i X Post95_t"
merge m:1 gvkey using cem_weights, keep(match) nogen
gen lognfamous95 = log(1+nfamous95)
gen interact2 = post95*lognfamous95
label var DiD_textual "Textual Treated Firm x Post 1995"
label var interact2 "log(1+NfamousTMs95) x Post 1995"
label var DiD "Treated firm x Post 1995"
gen famous_or_nothing=0
replace famous_or_nothing=1 if tmstock95==0 | treated==1
compress
save main_panel, replace






*extended sample:
use data/cc_panel_filtered_extend, clear
gen post95 = (year >= 1996)
gen post02 = (year >= 2003)
gen post06 = (year >= 2007)
gen DiD = treated*post95
label var DiD "Treated_i X Post95_t"
gen treated2 = 
merge m:1 gvkey using cem_weights, keep(match) nogen
compress
save extended_panel, replace





