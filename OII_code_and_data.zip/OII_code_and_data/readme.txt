May 2022

This package contains two code files and four data files that replicate all figures and tables from "On Index Investing" by Coles, Heath and Ringgenberg.

CRSP and Compustat (stock- and firm-level data) are proprietary data. Also, historical data on Russell index membership is proprietary to Russell Investments. For this reason the data have been anonymized with respect to stock- and firm-level identifiers. There is an anonymized stock-level identifier "stockid" which is consistent across the datasets.

The code files are:

1. model_figures.ipynb -- this Jupyter Notebook file reproduces Figure 1 from the paper.
2. Russell_tables_figures.do -- this Stata dofile reproduces all other figures and tables from the paper.

The data files are:

RDDpanel100_monthly.dta -- this panel contains stock-level monthly data for 11 months pre- and post-index reconstitution. The panel variable is stockid-by-cohort, for firms in Russell cohorts from 2007 to 2016, as described in the paper.

RDDpanel100_quarterly.dta -- this panel contains stock-level quarterly data for 3 quarters pre- and post-index reconstitution. The panel variable is stockid-by-cohort, for firms in Russell cohorts from 2007 to 2016, as described in the paper.

Russell_June_panel.dta -- this panel contains stock-level data as of May just prior to index reconstitution, for stocks in the Russell 3000 index as of June that year from 2007 to 2016. The panel variable is stockid.

time_series_means.dta -- this dataset contains mean monthly 4-day variance ratios (MVR4_) and mean passive holdings as a fraction of market capitalization, averaged across all stocks in the broad Russell panel, from 2007 to 2016.