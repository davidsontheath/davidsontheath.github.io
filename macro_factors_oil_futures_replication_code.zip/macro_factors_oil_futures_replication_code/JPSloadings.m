function [A_Z, B_Z, K0Q, K1Q, rho0, rho1] = JPSloadings(W, lamQ, pinf, sigma)

% inputs
% weighting matrix W, NxJ
% lamQ, diagonals of the minimal form K1QY, Nx1
% pinf, long run mean, scalar
% sigma, lower triangular root of the cov matrix of shocks in the Z form
% (the cP-and-M form, not the minimal form)
% gamma0M, gamma1M, loadings of M on cP

[L J] = size(W);

K1QY = diag(lamQ);
K0QY = [pinf; zeros(L-1,1)];


B_Y = zeros(J,L);
for j=1:J
    B_Y(j,:) = ones(1,L)*(K1QY + eye(L))^j;
end

WBY = W * B_Y;
invWBY = inv(WBY);
sigma_Y = invWBY * sigma;

A_Y = zeros(J,1);
A_Y(1) = pinf + 1/2*ones(1,L)*sigma_Y*sigma_Y.'*ones(L,1);
for j = 2:J
    A_Y(j) = A_Y(j-1)+B_Y(j-1,1)*pinf+1/2*B_Y(j-1,:)*sigma_Y*sigma_Y.'*B_Y(j-1,:).';
end

K1Q = WBY*K1QY*invWBY;
K0Q = WBY*[pinf;zeros(L-1,1)]-K1Q*W*A_Y;

rho0 = -ones(1,L)*invWBY*W*A_Y;
rho1 = ones(1,L)*invWBY;

B_Z = zeros(J,L);
for j=1:J
    B_Z(j,:) = rho1*(K1Q+ eye(L))^j;
end

A_Z = zeros(J,1);
A_Z(1) = rho0 + rho1*K0Q + 1/2*rho1*sigma*sigma.'*rho1.';
for j = 2:J
    A_Z(j) = A_Z(j-1)+B_Z(j-1,:)*K0Q+1/2*B_Z(j-1,:)*sigma*sigma.'*B_Z(j-1,:).';
end

end