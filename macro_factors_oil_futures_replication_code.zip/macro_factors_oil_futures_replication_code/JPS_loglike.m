function [LL, A, B, K0Q, K1Q, rho0, rho1, f_t_m, K0P, K1P, sigma_Z] = ...
    JPS_loglike(f_t, Zt, W, lamQ, pinf, sigma, restrictsLam, restrictsP)

% inputs are f_t, TxJ set of observed log futures prices
% Zt, TxN, obs of N factors
% W, LxJ, loadings for LCs of log prices assumed obs w/o error
% lamQ, Lx1 list of eigenvalues of K1QY 
% pinf, intercept term, scalar
% sigma, NxN *lower triangular root* of innovation covariance... 
% in the *Z form* (not the Y form)

[T,J] = size(f_t(2:end,:)); % LL is conditional on obs t=1

L = size(W,1);
N = size(Zt,2);
M = N - L;
cP = Zt(:,1:L);

[A, B, K0Q, K1Q, rho0, rho1] = JPSloadings(W, lamQ, pinf, sigma);

%f_t_m = ones(T+1,1)*A.'+cP*B.';

%f_t_errors = f_t_m(~isnan(f_t)) - f_t(~isnan(f_t));
%square_ortho_errors = f_t_errors.^2;
% concentrate sigma_err:
%sigma_err = sqrt(sum(square_ortho_errors(:))/size(f_t_errors,1));
%check that, since we cut out NaN f_ts, degs of freedom may be a tiny bit off
%loglike_Q = .5*sum(square_ortho_errors.')/sigma_err^2 + (J-L)*.5*log(2*pi) + .5*(J-L)*log(sigma_err^2);



f_t_m = ones(T+1,1)*A.'+cP*B.';

f_t_errors = f_t_m - f_t;
square_ortho_errors = f_t_errors.^2;
square_ortho_errors(isnan(square_ortho_errors(:)))=0;
% concentrate sigma_err:
n_obs = sum(~isnan(f_t_errors),2)-N;
sigma2_err = diag(nanvar(f_t_errors(:))*ones(J,1));
%above imposes errors the same for each maturity. Can instead do:
%sigma2_err = diag(nanvar(f_t_errors));
%bad_mats = diag(isnan(sigma2_err));
%sigma2_err(diag(bad_mats))=1;

if exist('sigma_err_in', 'var')
    sigma2_err = sigma2_err_in;
end

loglike_Q = .5*sum(square_ortho_errors*inv(sigma2_err),2) + n_obs*.5*log(2*pi) + .5*log(det(sigma2_err));






%Implied estimates of K0P, K1P:

if isempty(restrictsLam) && isempty(restrictsP)
    %ols
    [K1PplusI, K0P, sigma_Z2_P, K1P_se, K0P_se]= var_regress(Zt);
    K1P = K1PplusI-eye(N);
    
elseif ~isempty(restrictsLam) && isempty(restrictsP)
%restricted risk premiums    
    GLSresids = Zt(2:end,:)-Zt(1:end-1,:);
    GLSresids(:,1:L) = GLSresids(:,1:L)-Zt(1:end-1,1:L)*K1Q.'-ones(T,1)*K0Q.';
    [bgls,sigma_Z2_P,gls_se] = JoslinGLS(GLSresids,[ones(T,1),Zt(1:end-1,:)],[restrictsLam;zeros(M,N+1)]);
    K0P = bgls(:,1)+[K0Q;zeros(M,1)];
    K1P = bgls(:,2:end)+[K1Q,zeros(L,M);
                           zeros(M,N)] ;

elseif isempty(restrictsLam) && ~isempty(restrictsP)
%restricted P-dynams
    GLSresids = Zt(2:end,:)-Zt(1:end-1,:);
    [bgls,sigma_Z2_P,gls_se] = JoslinGLS(GLSresids,[ones(T,1),Zt(1:end-1,:)],restrictsP);
    K0P = bgls(:,1);
    K1P = bgls(:,2:end);
    
%do case where both Lam and P are restricted    
end

%sigmaZ_LxL, set equal to the param values coming in...
sigma_Z = chol(sigma_Z2_P, 'lower');
sigma_Z(1:L,1:L) = sigma;

%now compute log likelihood
innov = Zt(2:end,:).' - (K0P*ones(1,T) + (K1P+eye(N))*Zt(1:end-1,:).'); 

loglike_P = .5*N*log(2*pi) + .5*log(det(sigma_Z*sigma_Z.')) + .5*sum(innov.*((sigma_Z*sigma_Z.')\innov),1);

loglike = (loglike_Q(2:end) + loglike_P.');
LL = mean(loglike);


% [LL, A, B, K0Q, K1Q, rho0, rho1, f_t_m, K0P, K1P, sigma_Z, sigma2_err,loglike] = ...
%    JSZ_loglike(f_t, cP, W, lamQ, pinf, sigma)

end