%
% This file with all the supporting files
% replicates tables and figures in Heath (2018).
% DERIVEST suite written by John D'Errico.
% var_regress.m written by Scott Joslin.
% olsgmm.m written by John Cochrane.

%%%%%%%%%%%
% setup
%%%%%%%%%%%
clear all; close all; clc;
restoredefaultpath
cd('~/Dropbox/replication_code')
addpath(genpath(pwd));
beep off


load('data.mat')
f_t = log(data.F_t);
[T J] = size(f_t);


%Short-roll and excess-hold rtns following Szymanowksa et al (2014)
rtn.ShortRoll = f_t(2:end,1) - f_t(1:end-1,2);
rtn.ShortRoll2 = rtn.ShortRoll(1:end-1) + rtn.ShortRoll(2:end);
rtn.ShortRoll3 = rtn.ShortRoll(1:end-2) + rtn.ShortRoll(2:end-1) + ...
                 rtn.ShortRoll(3:end);
rtn.ShortRoll4 = rtn.ShortRoll(1:end-3) + rtn.ShortRoll(2:end-2) + ...
                 rtn.ShortRoll(3:end-1) + rtn.ShortRoll(4:end);
rtn.HoldRtn2 = f_t(3:end,1) - f_t(1:end-2,3);
rtn.HoldRtn3 = f_t(4:end,1) - f_t(1:end-3,4);
rtn.HoldRtn4 = f_t(5:end,1) - f_t(1:end-4,5);

rtn.ExcessHold2 = (rtn.HoldRtn2 - rtn.ShortRoll2)/2;
rtn.ExcessHold3 = (rtn.HoldRtn3 - rtn.ShortRoll3)/3;
rtn.ExcessHold4 = (rtn.HoldRtn4 - rtn.ShortRoll4)/4;


%interpolate f_t and compute PCs
mats = [1:J];
for t = 1:T
    f_tPC(t,:) = interp1(mats(~isnan(f_t(t,:))), ...
        f_t(t,~isnan(f_t(t,:))),mats,'linear', 'extrap');
end
f_t_mean = mean(f_tPC(:));
f_tPC = f_tPC - f_t_mean;
f_t = f_t - f_t_mean;
clear mats
[coeff,~,~,explvar] = pca(f_tPC);
coeff=(coeff.*(ones(J,1)*sign(coeff(1,:))))';
L = 2;
W = coeff(:,1:L);
cP = f_tPC*W;
%
M_t = [data.GRO data.INV];
%%%%%%%%%%%
% end setup
%%%%%%%%%%%






% Figure 1: plot the data
f = figure; hold on;
[ax,p1,p2] = plotyy(data.dates,[M_t(:,1) M_t(:,2)*5],data.dates,f_tPC+f_t_mean,'plot');
set(ax(2),'YLim',[0 5])
set(ax(1),'YLim',[-4 10])
set(p1(1),'LineWidth',2)
set(p1(2),'LineStyle','-','Marker','x')
xlim(ax(1), [data.dates(1) data.dates(end)])
xlim(ax(2), [data.dates(1) data.dates(end)])
datetick(ax(2),'x', 'yyyy')
datetick(ax(1),'x', 'yyyy')
set(ax(1),'XTick',[])
leg_fig = legend('GRO', 'INV','f_t^{1-12}');
set(leg_fig,'Location', 'northwest','FontSize',14)



%Figure 2: plot the PC loadings
%Panel A, levels
f = figure; hold on
plot(coeff(:,1),'-og','LineWidth',2)
plot(coeff(:,2),'-^b','LineWidth',2)
plot(coeff(:,3),'-xr','LineWidth',2)
plot([0:J+1],zeros(1,J+2),'-k')
xlim([0 J+1]);
ylim([-0.5 0.8])
xlabel('Futures maturity in months','FontSize',16)
ylabel('Loading','FontSize',16)
tit = title('PCs of Log Oil Futures Prices');
leg_fig = legend('PC1 -- 99.79%', 'PC2 -- 0.20%','PC3 -- 0.01%');
set(leg_fig,'Location', 'best','FontSize',18)
%Panel B, changes
df_tPC = f_tPC(2:end,:)-f_tPC(1:end-1,:);
[coeff,~,~,explvar] = pca(df_tPC);
coeff=(coeff.*(ones(J,1)*sign(coeff(1,:))))';
f = figure; hold on
plot(coeff(:,1),'-og','LineWidth',2)
plot(coeff(:,2),'-^b','LineWidth',2)
plot(coeff(:,3),'-xr','LineWidth',2)
plot([0:J+1],zeros(1,J+2),'-k')
xlim([0 J+1])
ylim([-0.5 0.8])
xlabel('Futures maturity in months','FontSize',16)
ylabel('Loading','FontSize',16)
tit = title('PCs of Log Oil Futures Changes');
leg_fig = legend('PC1 - 97.14%', 'PC2 - 2.57%','PC3 - 0.23%');
set(leg_fig,'Location', 'best','FontSize',18)







%%Table 1
cP5 = f_tPC*coeff(:,1:5);
%panel a: forecasting returns
Table1A = zeros(9,6);
nlags = 6;
[fcast, fcast_se, fcast_R2, fcast_adjR2] = olsgmm(rtn.ShortRoll,cP(1:end-1,1:2),nlags,1,1);
[residfcast, residfcast_se, residfcast_R2, residfcast_adjR2] = olsgmm(rtn.ShortRoll,[M_t(1:end-1,:) cP(1:end-1,1:2)],nlags,1,1);
fcastSS = sum((rtn.ShortRoll - [cP(1:end-1,1:2) ones(T-1,1)]* fcast).^2);
residSS = sum((rtn.ShortRoll - [M_t(1:end-1,:) cP(1:end-1,1:2) ones(T-1,1)]* residfcast).^2);
fstat = ((fcastSS - residSS)/2)/(residSS/(T-1-(2+2+1)));
fval = 1-fcdf(fstat, 2, (T-1-(2+2+1)));
Table1A(:,1) = [residfcast(1);-residfcast_se(1);residfcast(2);-residfcast_se(2);T-1;fcast_adjR2; residfcast_adjR2;fstat;fval];
[fcast, fcast_se, fcast_R2, fcast_adjR2] = olsgmm(rtn.ShortRoll,cP5(1:end-1,1:5),nlags,1,1);
[residfcast, residfcast_se, residfcast_R2, residfcast_adjR2] = olsgmm(rtn.ShortRoll,[M_t(1:end-1,:) cP5(1:end-1,1:5)],nlags,1,1);
fcastSS = sum((rtn.ShortRoll - [cP5(1:end-1,1:5) ones(T-1,1)]* fcast).^2);
residSS = sum((rtn.ShortRoll - [M_t(1:end-1,:) cP5(1:end-1,1:5) ones(T-1,1)]* residfcast).^2);
fstat = ((fcastSS - residSS)/2)/(residSS/(T-1-(2+5+1)));
fval = 1-fcdf(fstat, 2, (T-1-(2+5+1)));
Table1A(:,2) = [residfcast(1);-residfcast_se(1);residfcast(2);-residfcast_se(2);T-1;fcast_adjR2; residfcast_adjR2;fstat;fval];
[fcast, fcast_se, fcast_R2, fcast_adjR2] = olsgmm(rtn.ShortRoll,f_tPC(1:end-1,:),nlags,1,1);
[residfcast, residfcast_se, residfcast_R2, residfcast_adjR2] = olsgmm(rtn.ShortRoll,[M_t(1:end-1,:) f_tPC(1:end-1,:)],nlags,1,1);
fcastSS = sum((rtn.ShortRoll - [f_tPC(1:end-1,:) ones(T-1,1)]* fcast).^2);
residSS = sum((rtn.ShortRoll - [M_t(1:end-1,:) f_tPC(1:end-1,:) ones(T-1,1)]* residfcast).^2);
fstat = ((fcastSS - residSS)/2)/(residSS/(T-1-(2+12+1)));
fval = 1-fcdf(fstat, 2, (T-1-(2+12+1)));
Table1A(:,3) = [residfcast(1);-residfcast_se(1);residfcast(2);-residfcast_se(2);T-1;fcast_adjR2; residfcast_adjR2;fstat;fval];
[fcast, fcast_se, fcast_R2, fcast_adjR2] = olsgmm(rtn.ExcessHold3,cP(1:end-3,1:2),nlags,1,1);
[residfcast, residfcast_se, residfcast_R2, residfcast_adjR2] = olsgmm(rtn.ExcessHold3,[M_t(1:end-3,:) cP(1:end-3,1:2)],nlags,1,1);
fcastSS = sum((rtn.ExcessHold3 - [cP(1:end-3,1:2) ones(T-3,1)]* fcast).^2);
residSS = sum((rtn.ExcessHold3 - [M_t(1:end-3,:) cP(1:end-3,1:2) ones(T-3,1)]* residfcast).^2);
fstat = ((fcastSS - residSS)/2)/(residSS/(T-3-(2+2+1)));
fval = 1-fcdf(fstat, 2, (T-3-(2+2+1)));
Table1A(:,4) = [residfcast(1);-residfcast_se(1);residfcast(2);-residfcast_se(2);T-1;fcast_adjR2; residfcast_adjR2;fstat;fval];
[fcast, fcast_se, fcast_R2, fcast_adjR2] = olsgmm(rtn.ExcessHold3,cP5(1:end-3,1:5),nlags,1,1);
[residfcast, residfcast_se, residfcast_R2, residfcast_adjR2] = olsgmm(rtn.ExcessHold3,[M_t(1:end-3,:) cP5(1:end-3,1:5)],nlags,1,1);
fcastSS = sum((rtn.ExcessHold3 - [cP5(1:end-3,1:5) ones(T-3,1)]* fcast).^2);
residSS = sum((rtn.ExcessHold3 - [M_t(1:end-3,:) cP5(1:end-3,1:5) ones(T-3,1)]* residfcast).^2);
fstat = ((fcastSS - residSS)/2)/(residSS/(T-3-(2+5+1)));
fval = 1-fcdf(fstat, 2, (T-3-(2+5+1)));
Table1A(:,5) = [residfcast(1);-residfcast_se(1);residfcast(2);-residfcast_se(2);T-1;fcast_adjR2; residfcast_adjR2;fstat;fval];
[fcast, fcast_se, fcast_R2, fcast_adjR2] = olsgmm(rtn.ExcessHold3,f_tPC(1:end-3,:),nlags,1,1);
[residfcast, residfcast_se, residfcast_R2, residfcast_adjR2] = olsgmm(rtn.ExcessHold3,[M_t(1:end-3,:) f_tPC(1:end-3,:)],nlags,1,1);
fcastSS = sum((rtn.ExcessHold3 - [f_tPC(1:end-3,:) ones(T-3,1)]* fcast).^2);
residSS = sum((rtn.ExcessHold3 - [M_t(1:end-3,:) f_tPC(1:end-3,:) ones(T-3,1)]* residfcast).^2);
fstat = ((fcastSS - residSS)/2)/(residSS/(T-3-(2+12+1)));
fval = 1-fcdf(fstat, 2, (T-3-(2+12+1)));
Table1A(:,6) = [residfcast(1);-residfcast_se(1);residfcast(2);-residfcast_se(2);T-1;fcast_adjR2; residfcast_adjR2;fstat;fval];
%Panel B: forecasting PCs
dcP = cP(2:end,:)-cP(1:end-1,:);
Table1B = zeros(9,6);
[fcast, fcast_se, fcast_R2, fcast_adjR2] = olsgmm(dcP(:,1),cP(1:end-1,1:2),nlags,1,1);
[residfcast, residfcast_se, residfcast_R2, residfcast_adjR2] = olsgmm(dcP(:,1),[M_t(1:end-1,:) cP(1:end-1,1:2)],nlags,1,1);
fcastSS = sum((dcP(:,1) - [cP(1:end-1,1:2) ones(T-1,1)]* fcast).^2);
residSS = sum((dcP(:,1) - [M_t(1:end-1,:) cP(1:end-1,1:2) ones(T-1,1)]* residfcast).^2);
fstat = ((fcastSS - residSS)/2)/(residSS/(T-1-(2+2+1)));
fval = 1-fcdf(fstat, 2, (T-1-(2+2+1)));
Table1B(:,1) = [residfcast(1);-residfcast_se(1);residfcast(2);-residfcast_se(2);T-1;fcast_adjR2; residfcast_adjR2;fstat;fval];
[fcast, fcast_se, fcast_R2, fcast_adjR2] = olsgmm(dcP(:,1),cP5(1:end-1,1:5),nlags,1,1);
[residfcast, residfcast_se, residfcast_R2, residfcast_adjR2] = olsgmm(dcP(:,1),[M_t(1:end-1,:) cP5(1:end-1,1:5)],nlags,1,1);
fcastSS = sum((dcP(:,1) - [cP5(1:end-1,1:5) ones(T-1,1)]* fcast).^2);
residSS = sum((dcP(:,1) - [M_t(1:end-1,:) cP5(1:end-1,1:5) ones(T-1,1)]* residfcast).^2);
fstat = ((fcastSS - residSS)/2)/(residSS/(T-1-(2+5+1)));
fval = 1-fcdf(fstat, 2, (T-1-(2+5+1)));
Table1B(:,2) = [residfcast(1);-residfcast_se(1);residfcast(2);-residfcast_se(2);T-1;fcast_adjR2; residfcast_adjR2;fstat;fval];
[fcast, fcast_se, fcast_R2, fcast_adjR2] = olsgmm(dcP(:,1),f_tPC(1:end-1,:),nlags,1,1);
[residfcast, residfcast_se, residfcast_R2, residfcast_adjR2] = olsgmm(dcP(:,1),[M_t(1:end-1,:) f_tPC(1:end-1,:)],nlags,1,1);
fcastSS = sum((dcP(:,1) - [f_tPC(1:end-1,:) ones(T-1,1)]* fcast).^2);
residSS = sum((dcP(:,1) - [M_t(1:end-1,:) f_tPC(1:end-1,:) ones(T-1,1)]* residfcast).^2);
fstat = ((fcastSS - residSS)/2)/(residSS/(T-1-(2+12+1)));
fval = 1-fcdf(fstat, 2, (T-1-(2+12+1)));
Table1B(:,3) = [residfcast(1);-residfcast_se(1);residfcast(2);-residfcast_se(2);T-1;fcast_adjR2; residfcast_adjR2;fstat;fval];
[fcast, fcast_se, fcast_R2, fcast_adjR2] = olsgmm(dcP(:,2),cP(1:end-1,1:2),nlags,1,1);
[residfcast, residfcast_se, residfcast_R2, residfcast_adjR2] = olsgmm(dcP(:,2),[M_t(1:end-1,:) cP(1:end-1,1:2)],nlags,1,1);
fcastSS = sum((dcP(:,1) - [cP(1:end-1,1:2) ones(T-1,1)]* fcast).^2);
residSS = sum((dcP(:,1) - [M_t(1:end-1,:) cP(1:end-1,1:2) ones(T-1,1)]* residfcast).^2);
fstat = ((fcastSS - residSS)/2)/(residSS/(T-1-(2+2+1)));
fval = 1-fcdf(fstat, 2, (T-1-(2+2+1)));
Table1B(:,4) = [residfcast(1);-residfcast_se(1);residfcast(2);-residfcast_se(2);T-1;fcast_adjR2; residfcast_adjR2;fstat;fval];
[fcast, fcast_se, fcast_R2, fcast_adjR2] = olsgmm(dcP(:,2),cP5(1:end-1,1:5),nlags,1,1);
[residfcast, residfcast_se, residfcast_R2, residfcast_adjR2] = olsgmm(dcP(:,2),[M_t(1:end-1,:) cP5(1:end-1,1:5)],nlags,1,1);
fcastSS = sum((dcP(:,1) - [cP5(1:end-1,1:5) ones(T-1,1)]* fcast).^2);
residSS = sum((dcP(:,1) - [M_t(1:end-1,:) cP5(1:end-1,1:5) ones(T-1,1)]* residfcast).^2);
fstat = ((fcastSS - residSS)/2)/(residSS/(T-1-(2+5+1)));
fval = 1-fcdf(fstat, 2, (T-1-(2+5+1)));
Table1B(:,5) = [residfcast(1);-residfcast_se(1);residfcast(2);-residfcast_se(2);T-1;fcast_adjR2; residfcast_adjR2;fstat;fval];
[fcast, fcast_se, fcast_R2, fcast_adjR2] = olsgmm(dcP(:,2),f_tPC(1:end-1,:),nlags,1,1);
[residfcast, residfcast_se, residfcast_R2, residfcast_adjR2] = olsgmm(dcP(:,2),[M_t(1:end-1,:) f_tPC(1:end-1,:)],nlags,1,1);
fcastSS = sum((dcP(:,1) - [f_tPC(1:end-1,:) ones(T-1,1)]* fcast).^2);
residSS = sum((dcP(:,1) - [M_t(1:end-1,:) f_tPC(1:end-1,:) ones(T-1,1)]* residfcast).^2);
fstat = ((fcastSS - residSS)/2)/(residSS/(T-1-(2+12+1)));
fval = 1-fcdf(fstat, 2, (T-1-(2+12+1)));
Table1B(:,6) = [residfcast(1);-residfcast_se(1);residfcast(2);-residfcast_se(2);T-1;fcast_adjR2; residfcast_adjR2;fstat;fval];





%Figure 3
SMt = [cP(:,1:2) ones(T,1)]*olsgmm(M_t,cP(:,1:2),0,0,1);
UMt = M_t-SMt;
%Panel A: spanned vs unspanned components of GRO
f = figure; hold on
plot(data.dates,UMt(:,1),'-g','LineWidth',2.5)
plot(data.dates,SMt(:,1),'-b','LineWidth',2.5)
datetick('x', 'yyyy')
xlim([data.dates(1)-300 data.dates(end)+300])
ylabel('CFNAI Index','FontSize',14,'Interpreter','latex');
leg_fig = legend('UGRO', 'SGRO');
set(leg_fig, 'Interpreter', 'latex', 'Location', 'best','FontSize',14);
%Panel B: spanned vs unspanned components of INV
f = figure; hold on
plot(data.dates,UMt(:,2),'-g','LineWidth',2.5)
plot(data.dates,SMt(:,2),'-b','LineWidth',2.5)
datetick('x', 'yyyy')
xlim([data.dates(1)-300 data.dates(end)+300])
ylabel('Log U.S. Oil Inventory','FontSize',14,'Interpreter','latex');
leg_fig = legend('UINV','SINV');
set(leg_fig, 'Interpreter', 'latex', 'Location', 'best','FontSize',14);





%%%%%%%%%%%%%%%%%%%%%
%Main model estimate:
%%%%%%%%%%%%%%%%%%%%%
est = estimate_stct(f_t, M_t);
est = get_SEs(est);


%Table 2: main estimate:
est.K0P
est.K0P_SE
est.K1P
est.K1P_SE
est.K0Q
est.K0Q_SE
est.K1Q
est.K1Q_SE
est.shock_corr
est.shock_vol
%Table 3: Risk premium loadings
est.Lambda0
est.Lambda0_SE
est.Lambda1_standardized
est.Lambda1_standardized_SE








%Figure 4: IRFs
Zt = [est.cP est.M_t];
reorder = [3,1,2,4];
Zt = Zt(:,reorder);
K1PplusI = est.K1P(reorder, reorder)+eye(est.N);
K0P = est.K0P(reorder); 
K1P = est.K1P(reorder, reorder);
temp = (est.sigma*est.sigma');
sigma = chol(temp(reorder,reorder),'lower');
dZt = Zt(2:end,:)-Zt(1:end-1,:);
Ztinnov = dZt-ones(T-1,1)*est.K0P.'-Zt(1:end-1,:)*est.K1P.';
%Panel A: Unit shock to s_t
IRF =[0 9.9 0 0]*sigma';
Tmax = 24;
for i=2:Tmax
    IRF(i,:) = IRF(i-1,:)*K1PplusI.';
end
f = figure; hold on;
set(f, 'PaperPositionMode', 'manual');  
set(f, 'PaperUnits', 'inches');
set(f, 'PaperPosition', [0.25 2.5 12.0 6.0]);
plot([0:Tmax-1],IRF(:,1),'-g^','LineWidth',1.5)
plot([0:Tmax-1],IRF(:,2),'-b','LineWidth',1.5)
plot([0:Tmax-1],IRF(:,3),'--b','LineWidth',1.5)
plot([0:Tmax-1],IRF(:,4),'-ro','LineWidth',1.5)
plot([0:Tmax-1],zeros(Tmax,1),'-k','LineWidth',1)
xlim([0 Tmax-1])
ylim([-.9 1.2])
xlabel('Horizon (months)','FontSize',14)
ylabel('Impulse Response','FontSize',14)
tit = title('\underline{Unit shock to $$s_t$$}');
set(tit, 'Interpreter', 'latex', 'FontSize', 18)
leg_fig = legend('GRO','$$s_t$$','$$c_t$$','INV');
set(leg_fig, 'Interpreter', 'latex', 'Location', 'best','FontSize',14)
%Panel B: transient shock to s_t
IRF =[0 9.9 -20 0]*sigma';
Tmax = 24;
for i=2:Tmax
    IRF(i,:) = IRF(i-1,:)*K1PplusI.';
end
f = figure; hold on;
set(f, 'PaperPositionMode', 'manual');  
set(f, 'PaperUnits', 'inches');
set(f, 'PaperPosition', [0.25 2.5 12.0 6.0]);
plot([0:Tmax-1],IRF(:,1),'-g^','LineWidth',1.5)
plot([0:Tmax-1],IRF(:,2),'-b','LineWidth',1.5)
plot([0:Tmax-1],IRF(:,3),'--b','LineWidth',1.5)
plot([0:Tmax-1],IRF(:,4),'-ro','LineWidth',1.5)
plot([0:Tmax-1],zeros(Tmax,1),'-k','LineWidth',1)
xlim([0 Tmax-1])
xlabel('Horizon (months)','FontSize',14)
ylabel('Impulse Response','FontSize',14)
tit = title('\underline{Transient shock to $$s_t$$}');
set(tit, 'Interpreter', 'latex', 'FontSize', 18)
leg_fig = legend('GRO','$$s_t$$','$$c_t$$','INV');
set(leg_fig, 'Interpreter', 'latex', 'Location', 'best','FontSize',14)
%Panel C: Shock to c_t
IRF =[0 0 18 0]*sigma';
Tmax = 24;
for i=2:Tmax
    IRF(i,:) = IRF(i-1,:)*K1PplusI.';
end;
f = figure; hold on;
set(f, 'PaperPositionMode', 'manual');  
set(f, 'PaperUnits', 'inches');
set(f, 'PaperPosition', [0.25 2.5 12.0 6.0]);
plot([0:Tmax-1],IRF(:,1),'-g^','LineWidth',1.5)
plot([0:Tmax-1],IRF(:,2),'-b','LineWidth',1.5)
plot([0:Tmax-1],IRF(:,3),'--b','LineWidth',1.5)
plot([0:Tmax-1],IRF(:,4),'-ro','LineWidth',1.5)
plot([0:Tmax-1],zeros(Tmax,1),'-k','LineWidth',1)
xlim([0 Tmax-1])
xlabel('Horizon (months)','FontSize',14)
ylabel('Impulse Response','FontSize',14)
tit = title('\underline{Unit shock to GRO}');
set(tit, 'Interpreter', 'latex', 'FontSize', 18)
leg_fig = legend('GRO','$$s_t$$','$$c_t$$','INV');
set(leg_fig, 'Interpreter', 'latex', 'Location', 'best','FontSize',14)
%Panel D: Shock to GRO
IRF =[1.9 0 0 0]*sigma';
Tmax = 24;
for i=2:Tmax
    IRF(i,:) = IRF(i-1,:)*K1PplusI.';
end;
f = figure; hold on;
set(f, 'PaperPositionMode', 'manual');  
set(f, 'PaperUnits', 'inches');
set(f, 'PaperPosition', [0.25 2.5 12.0 6.0]);
plot([0:Tmax-1],IRF(:,1),'-g^','LineWidth',1.5)
plot([0:Tmax-1],IRF(:,2),'-b','LineWidth',1.5)
plot([0:Tmax-1],IRF(:,3),'--b','LineWidth',1.5)
plot([0:Tmax-1],IRF(:,4),'-ro','LineWidth',1.5)
plot([0:Tmax-1],zeros(Tmax,1),'-k','LineWidth',1)
xlim([0 Tmax-1])
xlabel('Horizon (months)','FontSize',14)
ylabel('Impulse Response','FontSize',14)
tit = title('\underline{Unit shock to GRO}');
set(tit, 'Interpreter', 'latex', 'FontSize', 18)
leg_fig = legend('GRO','$$s_t$$','$$c_t$$','INV');
set(leg_fig, 'Interpreter', 'latex', 'Location', 'best','FontSize',14)







%estimate the 2-factor model with perfect spanning:
est_nomacro = estimate_stct(f_t,[]);

%Figure 5
%Panel A: compare spot premiums
f = figure; hold on;
set(f, 'PaperPositionMode', 'manual');  
set(f, 'PaperUnits', 'inches');
set(f, 'PaperPosition', [0.25 2.5 15.0 6.0]);
plot(data.dates,est.Lambda_t(:,1),'-b','LineWidth',2);
plot(data.dates,est_nomacro.Lambda_t(:,1),'-r','LineWidth',2);
d=plot(data.dates(1:end-3), rtn.ShortRoll3/3,':k','LineWidth',2);
yl = [-.3 0.3];
nber2 = data.nber*(yl(2)-yl(1))+yl(1);
plot(data.dates,zeros(est.T,1),'-k','LineWidth',1)
datetick('x', 'yyyy')
xlim([data.dates(1) data.dates(end)]);
ylabel('Monthly Log Return','FontSize',16)
ylim(yl);
leg_fig = legend('Unspanned Macro Model   ', 'Spanned Risk Model   ', 'Average Short Roll Return  ');
uistack(d,'down',20);
p = patch(data.dates, nber2, [.8 .8 .8]);
set(p,'EdgeColor','none')
uistack(p, 'down', 20);
%Panel B: compare term premiums
f = figure; hold on;
set(f, 'PaperPositionMode', 'manual');  
set(f, 'PaperUnits', 'inches');
set(f, 'PaperPosition', [0.25 2.5 15.0 6.0]);
plot(data.dates,est.Lambda_t(:,2),'-b','LineWidth',2)
plot(data.dates,est_nomacro.Lambda_t(:,2),'-r','LineWidth',2)
d=plot(data.dates(1:end-3), rtn.ExcessHold3,':k','LineWidth',2);
yl = [-0.1 0.1];
nber2 = data.nber*(yl(2)-yl(1))+yl(1);
plot(data.dates,zeros(est.T,1),'-k','LineWidth',1)
datetick('x', 'yyyy')
xlim([data.dates(1) data.dates(end)]);
ylabel('Monthly Log Return','FontSize',16)
ylim(yl);
leg_fig = legend('Unspanned Macro Model   ', 'Spanned Risk Model   ', 'Average Excess Holding Return  ');
uistack(d,'down',20);
p = patch(data.dates, nber2, [.8 .8 .8]);
set(p,'EdgeColor','none')
uistack(p, 'down', 20);






%Table 5: Risk premium loadings
M_t2 = [data.GRO data.CPI data.SPF];
M_t2_mean = mean(M_t2);
M_t2 = M_t2 - ones(size(M_t2,1),1)* M_t2_mean;
est = estimate_stct(f_t, M_t2);
est = get_SEs(est);
est.Lambda0
est.Lambda0_SE
est.Lambda1_standardized
est.Lambda1_standardized_SE







%Table 6: Physical measure dynamics with GRO+ and GRO-
GROpos = data.GRO.*([1;data.GRO3(1:end-1)>0]);
GROneg = data.GRO.*([0;data.GRO3(1:end-1)<0]);
M_t2 = [data.GROpos data.GROneg];
est = estimate_stct(f_t, [1 0;M_t2]);
est = get_SEs(est);
est.K0P
est.K0P_SE
est.K1P
est.K1P_SE





%Table 7: Physical measure dynamics with PI and PCH
M_t2 = [data.GROSUB(:,1)/3 data.GROSUB(:,3)];
est = estimate_stct(f_t, M_t2);
est = get_SEs(est);
est.K0P
est.K0P_SE
est.K1P
est.K1P_SE





%Table 8: Physical measure dynamics with GRO and HP
M_t2 = [data.GRO data.HP];
est = estimate_stct(f_t, M_t2);
est = get_SEs(est);
est.K0P
est.K0P_SE
est.K1P
est.K1P_SE




%the real options valuation example (Figure 6) uses large monte carlo loops
%that take a long time to run. Available on request.


