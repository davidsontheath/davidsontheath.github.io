function [Gamma, alpha, Omega, Gamma_hat_se, alpha_hat_se, Omega_hat_se, vecAlphahGammah_cov] = var_regress(X)
% function [Gamma, alpha, Omega, Gamma_hat_se, alpha_hat_se, Omega_hat_se, vecAlphahGammah_cov] = var_regress(X)
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Estimate first order VAR:
%   X(t+1) = alpha + Gamma*X(t) + eps(t+1), cov(eps(t+1)) = Omega
%
% Compute the maximum likelihood estimates of Gamma, alpha, Omega
%
% NOTE: The MLE estimates of Gamma, alpha do not depend on Omega.
% That is, the argmax_{Gamma,alpha} [L(X|Gamma,alpha,Omega)] = f(X)
% So this function provides MLE of Gamma, alpha for a fixed Omega.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% X: T*N
%
% Gamma_hat : N*N
% alpha_hat : N*1
% Omega_hat : N*N
% Gamma_hat_se : N*N
% alpha_hat_se : N*N
% Omega_hat_se : N*N
% vecGammahAlphah_cov : [N*(N+1)]x[N*(N+1)] -- estimate of cov(vec([alpha_hat, Gamma_hat]))
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


[T,N] = size(X);

Yt = X(1:end-1,:);  % (T-1)*N
Ytp1 = X(2:end,:);  % (T-1)*N

Y = Ytp1.';  % N*(T-1) 
Z = [ones(T-1,1), Yt].'; % (N+1)*(T-1)
A = Y*Z.'*inv(Z*Z.'); % N*(N+1)
alpha = A(:,1);
Gamma = A(:,2:end);

if nargout>=3
    residuals = Ytp1 - (A*Z).'; % (T-1)*N
    Omega = 1/(T-1)*residuals.'*residuals;
end

if nargout>=4    
    % cov is an estimate of cov( vec([alpha_hat, Gamma_hat]) )
    cov = (kron(inv(Z*Z'), Omega)); % [N*(N+1)]x[N*(N+1)]
    ses = reshape(sqrt(diag(cov)), [N,N+1]);
    Gamma_hat_se = ses(:,2:end);
    alpha_hat_se = ses(:,1);
    vecAlphahGammah_cov = cov;
    
    Omega_hat_se = 1/sqrt(T-1)*( Omega.^2 + diag(Omega)*diag(Omega).').^0.5;
end

