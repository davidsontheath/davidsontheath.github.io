function est = estimate_MLE(f_t, M_t, L, restrictsLam, restrictsP, cP, W)

%inputs:
% f_t, TxJ log futures price data. Both maturities and time-steps are monthly.
% Missing observations must be NaN.
% Mt, TxM macro factors data
% L, the number of spanned pricing factors
% restrictsLam, Nx(N+1_optional, zero restrictions on risk premium loadings
% restrictsP, Nx(N+1) optional, zero restrictions on the P-measure dynamics
% cP, LxT optional, values of the spanned pricing factors
% W, LxJ optional, loading matrix that produces cP = W * f_t (f_t filled)
% If either of cP and W are not specified, autofill any missing obs in f_t
% and compute cP and W from principal components of f_t.
%
%outputs:
% Loglikelihood LL, loadings on state vars A, B, fitted prices f_t_m, 
% model parameters K0Q, K1Q, rho0, rho1, f_t_m, K0P, K1P, sigma,

%%%%%%%%%%%%%%%%%%%%%%%%%

[T J] = size(f_t);
M = size(M_t, 2);
N = L + M;

if ~exist('cP','var')
    %Fill log futures prices and compute PCs:
    mats = [1:J];
    for t = 1:T
        f_tPC(t,:) = interp1(mats(~isnan(f_t(t,:))), ...
            f_t(t,~isnan(f_t(t,:))),mats,'linear', 'extrap');
    end
    [coeff,~,~,explvar] = pca(f_tPC);
    coeff=(coeff.*(ones(J,1)*sign(coeff(1,:))))';
    W = coeff(:,1:L).';
    cP = f_tPC*W.';
end
%check L is congruent with cP and W:


if ~exist('restrictsLam', 'var')
   restrictsLam = [];
end

if ~exist('restrictsP', 'var')
   restrictsP = [];
end


Zt = [cP M_t];

% Estimate sigma
[K1PplusI, K0P_init, sigma_P_est, K1P_se, K0P_se] = var_regress(Zt);
K1P_init = K1PplusI-eye(N);
sigma_init = chol(sigma_P_est(1:L,1:L),'lower');
inds = find(tril(ones(L)));
sigma_init_vec = sigma_init(inds);


llk_JPS = @(dlamQ, pinf, sigma_v) llk_JPS0(f_t, Zt, W, dlamQ, pinf, sigma_v, ...
    restrictsLam, restrictsP); %takes inputs in vectorized form

nSeeds = 100;
bestllk = inf;
for n=1:nSeeds
    % generate seeds for pinf and lamQ
    dlamQ = -.1*rand;
    dlamQ(2:L,1) = -diff(sort([dlamQ(1); rand(L-1,1)]));
    p_init = randn*.01;
    llk = llk_JPS(dlamQ, p_init, sigma_init_vec);
    if llk<bestllk
        fprintf('Improved seed llk to %5.5g\n',llk)
        bestllk = llk;
        dlamQ0 = dlamQ;
        p0 = p_init;
    end
end
clear dlamQ p_init



%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% constrained search
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fprintf('Local search...')

X0 = [dlamQ0; p0; sigma_init_vec]; % L, 1, Lx(L+1)/2
N_1 = L + 1 + L*(L+1)/2;  %should = length of X0
if ~(N_1 == numel(X0)) 
    error('wrong # of elements in X0!');
end

% constrain search so the most negative eigenvalue (=sum(dlamQ)) is greater than -mlam
Acon = [-ones(1,L), 0, zeros(1,L*(L+1)/2)];
mlam = 2;
Bcon = mlam;
Aeq = [];
Beq = [];

% Bounds for eigenvalues:
LB = [-1,-inf*ones(1,L-1)]; %first eig > -1, all others unconstrained below
UB = [.1,zeros(1,L-1)]; %first eig < 0.1, all other dlams must be negative

%no bounds for pinf
LB(L+1) = -inf;
UB(L+1) = inf;

% Bounds for sigma
A0 = ones(L);
inds_diag = find(ismember(find(tril(A0)), find(diag(diag(A0)))));
inds_offdiag = find(~ismember(find(tril(A0)), find(diag(diag(A0)))));
LB(inds_diag+L+1) = 1e-8;
LB(inds_offdiag+L+1) = -inf;
UB(L+2:numel(LB)) = inf;

opts = optimset('display','off','TolX',1e-8,'TolFun',1e-8,...
    'MaxFunEvals', 1e8, 'Algorithm', 'active-set');

%MLE estimate
[X2, llk, ans, ans, ans, ans, LLK_Hess] = fmincon(@(Z) ... 
    llk_JPS(Z(1:L), Z(L+1), Z(L+2:N_1)), ...
     X0,Acon,Bcon,Aeq,Beq,LB,UB,[],opts);

[LL, A, B, K0Q, K1Q, rho0, rho1, f_t_m, K0P, K1P, sigma] = llk_JPS0(f_t, Zt, W, ...
    X2(1:L), X2(L+1), X2(L+2:N_1), restrictsLam, restrictsP);
param = X2;

est.T = T;
est.J = J;
est.f_t = f_t;
est.L = L;
est.N = N;
est.M = M;
est.LL = LL;
est.A = A;
est.B = B;
est.K0Q = K0Q;
est.K1Q = K1Q;
est.rho0 = rho0;
est.rho1 = rho1;
est.f_t_m = f_t_m;
est.K0P = K0P;
est.K1P = K1P;
est.sigma = sigma;
est.param = param;
est.M_t = M_t;
est.cP = cP;
est.W = W;
if exist('f_tPC','var')
    est.f_tPC = f_tPC;
end
est.shock_corr = tril(corrcov(sigma*sigma'));
est.shock_vol = sqrt(diag(sigma'*sigma));
est.Lambda0 = K0P(1:L,:) - K0Q;
est.Lambda1 = K1P(1:L,:) - [K1Q,zeros(L,M)];
est.Lambda1_standardized = est.Lambda1.*(ones(L,1)*est.shock_vol');
est.Lambda_t = ones(T,1) * est.Lambda0' + [cP M_t] * est.Lambda1';



%unspanned and spanned components of M_t
if ~isempty(M_t)
        SM_t = [cP ones(T,1)]*olsgmm(M_t,cP,0,0,1);
        est.UM_t = M_t-SM_t;
        est.SM_t = SM_t;
        est.M_t_fractionspanned = std(SM_t) ./ std(M_t);
 end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


