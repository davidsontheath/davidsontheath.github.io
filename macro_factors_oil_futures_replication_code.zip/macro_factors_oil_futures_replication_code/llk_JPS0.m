function [llk, A, B, K0Q, K1Q, rho0, rho1, f_t_m, K0P, K1P, sigma_out,stct,K1Q_stct,K1P_stct,Lambda1_stct,sigma_stct] ...
            = llk_JPS0(f_t, Zt, W, dlamQ, pinf, sigma_v, restrictsLam, restrictsP)
%function [llk, A, B, K0Q, K1Q, rho0, rho1, f_t_m, K0P, K1P, sigma_out] = llk_JPS0(f_t, Zt, W, dlamQ, pinf, sigma_v, restricts)
%this function just unpacks the parameters coming in
%and then computes log likelihood for a JPS-form model
%with a cutout for errors or weird values of llk.


%unpack lambdas %%%%%%%%%%%%%%%%%%%%%%
L = length(dlamQ);
lamQ = cumsum(dlamQ);
%unpack sigma %%%%%%%%%%%%%%%%%%%
sigma_unpack = zeros(L);
inds = find(tril(ones(L)));
sigma_unpack(inds) = sigma_v;

default_llk = 1e6;
try
    warning off
    [llk, A, B, K0Q, K1Q, rho0, rho1, f_t_m, K0P, K1P, sigma_out] =...
        JPS_loglike(f_t, Zt, W, lamQ, pinf, sigma_unpack, restrictsLam, restrictsP);
    warning on
    if ~isempty(lastwarn)
        save('warn_work_space.mat'); %save crappy params that gave an error
        lastwarn(''); % reset warning message
    end
    
    if isnan(llk) || ~isreal(llk) || ~isfinite(llk)
        llk = default_llk;
    end
catch
	llk = default_llk;
end

end
