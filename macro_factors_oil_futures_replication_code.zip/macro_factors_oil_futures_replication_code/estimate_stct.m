function estSC = estimate_stct(f_t, M_t, restrictsLam, restrictsP)


% first estimate the unrestricted model with 2 spanned factors
% where the spanned factors are given by first 2 PCs of the data
est2F = estimate_MLE(f_t, M_t, 2);

 
% now rotate cP and W so the 2 spanned factors are st and ct
L = est2F.L;
T = est2F.T;
M = est2F.M;
f_tPC = est2F.f_tPC;
W = est2F.W;

rot1 = [est2F.rho1.', est2F.K1Q'*est2F.rho1.'];
sigma2_s = rot1(:,1)'*est2F.sigma(1:L,1:L)*est2F.sigma(1:L,1:L)'*rot1(:,1);
rot0 = [est2F.rho0, est2F.rho1*est2F.K0Q+1/2*sigma2_s];
% scale cost of carry ct to be annualized
rot0(2) = rot0(2)*12;
rot1(:,2) = rot1(:,2)*12;

Wstct = rot1'*W;
stct = f_tPC*Wstct';

estSC = estimate_MLE(est2F.f_t, est2F.M_t, 2, [], [], stct, Wstct);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% check that stct implied by the new estimate equals cP:
rot1 = [estSC.rho1.', estSC.K1Q'*estSC.rho1.'];
sigma2_s = rot1(:,1)'*estSC.sigma(1:L,1:L)*estSC.sigma(1:L,1:L)'*rot1(:,1);
rot0 = [estSC.rho0, estSC.rho1*estSC.K0Q+1/2*sigma2_s];
% scale cost of carry ct to be annualized
rot0(2) = rot0(2)*12;
rot1(:,2) = rot1(:,2)*12;

Wstct_step2 = rot1'*Wstct;
stct_step2 = f_tPC*Wstct';

if max(abs(stct(:) - stct_step2(:))) > 1e-8
    display('possible convergence issues with rotation to stct!')
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%



