function est = get_SEs(est)

% Given an estimate of the affine model, get standard errors via the delta method
L = est.L;
M = est.M;
N = M+L;
W = est.W;
cP = est.cP;
f_t = est.f_t;
M_t = est.M_t;
Z_t = [cP M_t];
param = est.param;

if ~exist('restrictsLam', 'var')
   restrictsLam = [];
end
if ~exist('restrictsP', 'var')
   restrictsP = [];
end



delta_fd = zeros(length(param), L+L^2+1+L);
stepsize = 1e-8;

% baseline #s to difference from:
[b.LL, b.A, b.B, b.K0Q, b.K1Q, b.rho0, b.rho1, b.f_t_m, b.K0P, b.K1P, b.sigma] ...
    = llk_JPS0(f_t, Z_t, W, param(1:L), param(L+1), param(L+2:end), restrictsLam, restrictsP);

% finite difference deltas
for n = 1:length(param)
    Z = param;
    Z(n) = Z(n)+stepsize;
    [d.LL, d.A, d.B, d.K0Q, d.K1Q, d.rho0, d.rho1] = llk_JPS0(f_t, Z_t, W, Z(1:L), Z(L+1), Z(L+2:end), restrictsLam, restrictsP);
    delta_fd(n,:) = [(d.K0Q-b.K0Q)', reshape(d.K1Q-b.K1Q,1,L^2), d.rho0-b.rho0, d.rho1-b.rho1]/stepsize;
end



llk_JPS = @(dlamQ, pinf, sigma_v) llk_JPS0(f_t, Z_t, W, dlamQ, pinf, sigma_v, restrictsLam, restrictsP); %takes inputs in vectorized form

% Hessian of the loglikelihood:
hess_est = hessian(@(Z) llk_JPS(Z(1:L), Z(L+1), Z(L+2:end)), param);
%grad_est = gradest(@(Z) llk_JPS(Z(1:L), Z(L+1), Z(L+2:end)), param);
%grad_est = sj_gradient(@(Z) llk_JPS(Z(1:L), Z(L+1), Z(L+2:end)),param);





%if isempty(restrictsLam) && isempty(restrictsP)
    %ols
    [ans, ans, ans, K1P_SE, K0P_SE]= var_regress(Z_t);
    
%elseif ~isempty(restrictsLam) && isempty(restrictsP)
%restricted risk premiums    
%    GLSresids = Zt(2:end,:)-Zt(1:end-1,:);
%    GLSresids(:,1:L) = GLSresids(:,1:L)-Zt(1:end-1,1:L)*K1Q.'-ones(T-1,1)*K0Q.';
%    [bgls,sigma_Z2_P,gls_se] = JoslinGLS(GLSresids,[ones(T-1,1),Zt(1:end-1,:)],[restrictsLam;zeros(M,N+1)]);
%    K0P_se = gls_se(:,1);
%    K1P_se = gls_se(:,2:end);

%elseif isempty(restrictsLam) && ~isempty(restrictsP)
%restricted P-dynams
%    GLSresids = Zt(2:end,:)-Zt(1:end-1,:);
%    [bgls,sigma_Z2_P,gls_se] = JoslinGLS(GLSresids,[ones(T-1,1),Zt(1:end-1,:)],restrictsP);
%    K0P_se = gls_se(:,1);
%    K1P_se = gls_se(:,2:end);
    
%do case where both Lam and P are restricted    
%end

SE_pars = sqrt(diag(inv(hess_est)));
dlamQ = param(1:L);
lamQ = cumsum(dlamQ);
dlamQ_se = SE_pars(1:L);
lamQ_se = cumsum(dlamQ_se);
pinf_se = SE_pars(L+1);
sigma_se = zeros(L);
inds = find(tril(ones(L)));
sigma_se(inds) = SE_pars(L+2:end);
SE_model = sqrt(diag(delta_fd'*inv(hess_est)*delta_fd)); %K0Q, K1Q, rho0, rho1
K0Q_SE = SE_model(1:L);
K1Q_SE = reshape(SE_model(L+1:L+L^2),L,L);
rho0_SE = SE_model(L^2+L+1);
rho1_SE = SE_model(L^2+L+2:end)';
%the 2 lines below are slightly wrong-ish, just adds 'em up...
Lambda0_SE = K0Q_SE+K0P_SE(1:L);
Lambda1_SE = [K1Q_SE,zeros(L,N-L)]+K1P_SE(1:L,:);

%if sum(restrictsLam(:)+restrictsP(:)) > 0
%        K0_restricts = restricts(1:L);
%        K1_restricts = restricts(L+1:end);
%        K1Q_se_pad = zeros(N,N); K1Q_se_pad(1:L,1:L) = K1Q_se;
%        K0P_se(find(K0_restricts>0)) = K0Q_se(find(K0_restricts>0));
%        K1P_se(find(K1_restricts>0)) = K1Q_se_pad(find(K1_restricts>0));
%        Lambda0_se = K0Q_se+K0P_se(1:L); %prob too big, fix to be correct
%        Lambda1_se = [K1Q_se,zeros(L,M)]+K1P_se(1:L,:); %prob too big, fix to be correct
%end


sigma = est.sigma;
T = est.T;
shock_corr = corrcov(sigma*sigma');
shock_corr_SE = (ones(N)-shock_corr.^2)./sqrt(T-1);

est.K0P_SE = K0P_SE;
est.K1P_SE = K1P_SE;
est.K0Q_SE = K0Q_SE;
est.K1Q_SE = K1Q_SE;
est.Lambda0_SE = Lambda0_SE;
est.Lambda1_SE = Lambda1_SE;
est.Lambda1_standardized_SE = Lambda1_SE.*(ones(L,1)*est.shock_vol');
est.rho0_SE = rho0_SE;
est.rho1_SE = rho1_SE;
est.shock_corr_SE = shock_corr_SE;
