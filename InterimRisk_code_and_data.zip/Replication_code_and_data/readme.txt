1. Introduction

The accompanying Stata 17 dofile "Interim_Risk_Mergers_replicationcode.do" and the two main data files "mergers_main.dta" and "daily_index_rtns.dta" reproduce all tables and figures from the paper "Market Returns and Interim Risk in Mergers", by Davidson Heath and Mark Mitchell.

Because the SDC and CRSP/Compustat data in the two data files cannot be shared publicly, this file includes the Stata 17 code to construct the mergers_main data file. The other data that are publicly available have been included in this replication package. (see "4. Code to construct main data files", below).

Also included are a variable dictionary for all variables in the datafiles (see "2. Variable dictionaries" below), and the Stata output (tables and figures and log file (rep_code_interim_risk.log) from running the main dofile using the two main data files.

Any questions, comments or issues please contact the corresponding author at davidson.heath@eccles.utah.edu.






2. Variable dictionaries

2.1 daily_index_rtns.dta

date - Calendar date
vwretd - daily return to the CRSP value-weighted U.S. equity market index


2.1 mergers_main.dta

DateAnnounced - Date the merger or acquisition was announced
PctOfCash - fraction of deal to be paid in cash
PctOfStock - fraction of deal to be paid in stock
AcquirorTotalAssets - total assets of the acquiring firm
dealID - deal-specific ID #
mktrtn - CRSP value-weighted market return over days +1 to +20 relative to DateAnnounced
down15 - = 1 if mktrtn < -0.15
down10 - = 1 if mktrtn < -0.10
down5 - = 1 if mktrtn < -0.05 
down - = 1 if mktrtn < 0 
withdrawn - = 1 if deal withdrawn
completed - = 1 if deal completed
dealpremium_w - premium paid over target's pre-announcement share price
logpremium - log(1+dealpremium_w)
year - year(DateAnnouced) 
TSIC4 - Target's 4-digit SIC industry
isrelated - = 1 if target and acquiror in the same 2-digit SIC industry
ishostile - = 1 if Deal Attitude was Hostile
isbuyout - = 1 if deal was a buyout by a financial firm
competing_bid - = 1 if there was a competing bidder
majoritycash - = 1 if PctOfCash > 0.5
majoritystock - = 1 if PctOfStock > 0.5
acq_withdrew - = 1 if acquiror firm withdrew
tgt_rejected - = 1 if target firm rejected the offer
public_acq - = 1 if acquiror firm was publicly listed
CAPE - Cyclically adjusted PE ratio from Robert Shiller's website
dCP - Change in commercial paper rate, days +1 to +20 relative to DateAnnounced
logValue - Deal Value
value_deflated - Deal Value in 2018 dollars deflated by CPI 
TgtSize - Assets of target firm
pre_agreed - = 1 if deal was announced with a definitive agreement in place
loginitprem - log(1+Initial premium proposed by acquiror firm)
revision - final deal price / initial proposed deal price
revised - = 1 if revision !=0
revised_down - =1 if revision > 0
revised_up - =1 if revision < 0
VIX - Average VIX index over the 20 trading days prior to DateAnnounced
tenderoffer - = 1 if deal was a public tender offer
tgt_beta - Monthly stock return beta of target firm over 12 months pre-announcement
acq_che - cash and cash equivalents of acquiror firm pre-announcement
logMB_acq - log (market/book) of acquiror firm 
logMB_tgt - log (market/book) of target firm 
acq_tang  - asset tangibility of acquiror firm
KZ - Kaplan-Zingales measure of financial constraints
SA - Size-Age measure of financial constraints
WW - Whited-Wu measure of financial constraints
tgt_age - age of target firm at announcement
tgt_vlt - monthly return volatility of target firm over 12 months pre-announcement





3. Inputs and code to construct data files

3.1 Input files:

daily_index_rtns.dta -- daily crsp VW index returns, from CRSP
mergers_temp.dta - mergers data file, from Thomson-Reuters SDC
CP_spreads.dta - +1 to +20 day change in commercial paper spread, from FRED
CPI.dta - consumer price index by date, from FRED
vix_prior_month.dta - average VIX index over 20 days prior to announcement, from Bloomberg


3.2 Stata 17 code:

use data/mergers_temp, replace
keep if Form=="Merger" | Form=="Acquisition" | Form=="Acq. Rem. Int." | Form=="Acq. Maj. Int." | Form=="Acq. of Assets"
keep if Status=="Completed" | Status=="Withdrawn"
gen withdrawn = (Status=="Withdrawn")
gen completed = (withdrawn==0)
gen PctBefore = PctOwnedAfterTransaction - PctofSharesAcq
drop if PctOwnedAfterTransaction < 50
drop if PctBefore >= 50 & PctBefore !=.
gen dealpremium = 1+Premium4weekspriortoann/100
drop if dealpremium ==.
replace dealpremium = 5 if dealpremium > 5
winsor dealpremium, p(.01) g(dealpremium_w)
gen logpremium = log(dealpremium_w)
egen DateFinal = rowmax(DateEffective DateWithdrawn)
drop if DateFinal==.
drop if DateAnnouncedisEstimated =="Yes"
gen year = year(DateAnnounced)
gen month = month(DateAnnounced)
gen qtr = quarter(DateAnnounced)
destring AcquirorPrimarySICCode, replace force
destring TargetPrimarySICCode, replace force
gen ASIC2 = floor(AcquirorPrimarySICCode/100)
gen TSIC2 = floor(TargetPrimarySICCode/100)
gen TSIC4 = TargetPrimarySICCode
gen ASIC4 = AcquirorPrimarySICCode
gen isrelated = (ASIC2==TSIC2)
gen ishostile = Attitude=="Hostile"
gen competing_bid = strpos(lower(CompetingBidder), "yes")>0
replace PctOfCash=0 if PctOfCash==.
replace PctOfStock=0 if PctOfStock==.
replace PctOfOther=0 if PctOfOther==.
gen majoritycash = (PctOfCash > 50)
gen majoritystock = (PctOfStock > 50)
gen public_acq = (acquirorpermno !=.)
gen public_tgt = (targetpermno !=.)
keep if public_tgt==1
ren DateAnnounced date
merge m:1 date using data/CP_spreads, keep(match master) nogen
ren date DateAnnounced
drop if year > 2018 | year < 1986
merge m:1 year using data/CPI, keep(match master) nogen 
gen value_deflated = ValueofTransaction / CPI
drop if value_deflated ==. 
keep if value_deflated > 50
gen logValue = log(value_deflated)
gen TgtSize = TargetTotalAssets/CPI
replace TgtSize = value_deflated if TgtSize==.
gen logTgtSize = log(TgtSize)
gen pre_agreed = (DefinitiveAgreementYN=="Yes") & DefinitiveAgreementDate <= DateAnnounced
gen initprem = InitialPrSh / TargetSharePrice4WeekPriorAnn
gen loginitprem = log(initprem)
ren ChangeFinalPricetoInitia revision
replace revision = 0 if revision==.
gen revised = revision !=0 & revision !=.
gen revised_down = revision !=0 & revision !=. & revision < 0
gen revised_up = revision !=0 & revision !=. & revision > 0
replace revision =. if revised_bid==0
merge 1:1 dealID using Data/vix_prior_month, keep(match master) nogen
replace vix_prior_month = vix_prior_month / 100
ren vix_prior_month VIX
replace CAPE = CAPE / 100
gen down15 = (mktrtn < -0.15)
gen down10 = (mktrtn < -0.1)
gen down5 = (mktrtn < -0.05)
gen down = (mktrtn < 0)
compress
save data/mergers_main, replace


